HASSE KANGAS / IN LATE JULY
PRESS KIT

Included
Four-page EPK and A4 One Sheet in English.
Preferred studio and piano press photographs in black and white.
Single artwork, 3000 x 3000 pixels, selected black variant.
Two 31-second WAV excerpts.

Credits
Words, music, all performances, recording, production, mixing and mastering:
Hasse Kangas.
Label: Frozen Hill.
Photography: Hasse Kangas.

Press photographs may be used in press coverage of Hasse Kangas and In Late July.
Please credit Hasse Kangas.

Audio excerpts
Intro: master 0:04-0:35.
Verse and chorus: master 1:32-2:03.
Release date: 29 January 2027.

Website
https://hassekangas.github.io/
Contact
manytracks@outlook.com
